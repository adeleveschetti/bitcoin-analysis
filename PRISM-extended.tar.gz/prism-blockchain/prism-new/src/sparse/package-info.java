/**
 * Access to the "Sparse" engine: sparse matrix data structures and corresponding implementations of model checking algorithms.
 */
package sparse;
