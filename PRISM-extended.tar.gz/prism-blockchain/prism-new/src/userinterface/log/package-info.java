/**
 * The "Log" tab in the GUI.
 */
package userinterface.log;
