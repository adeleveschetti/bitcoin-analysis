/**
 * Java port of the LTL to deterministic Rabin automata conversion library.
 */
package jltl2dstar;
