/*
 * Copyright 2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package parser.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;

import parser.type.TypeInt;
import prism.PrismTest;

/**
 * @author ycoppel@google.com (Yohann Coppel)
 * 
 * @param <T>
 *          Object's type in the tree.
 */
public class TreeList<T> {

	private ExpressionBlock head;

	private ExpressionBlock lastAdded ;

	private ArrayList<ArrayList<ExpressionBlock>> lists = new ArrayList<ArrayList<ExpressionBlock>>();

	private ArrayList<ExpressionBlock> nodes = new ArrayList<ExpressionBlock>();

	public TreeList() {
		this.head = null;
		//nodes.add(head);
		//ArrayList<ExpressionBlock> tmp = new ArrayList<ExpressionBlock> ();
		//tmp.add(head);
		//lists.add(tmp);
	}

	public TreeList(ExpressionBlock head) {
		this.head = head;
		this.lastAdded = head;
		nodes.add(head);
		ArrayList<ExpressionBlock> tmp = new ArrayList<ExpressionBlock> ();
		tmp.add(head);
		lists.add(tmp);
	}

	public void addHead(ExpressionBlock head) {
		this.head = head;
		this.lastAdded = head;
		nodes.add(head);
		ArrayList<ExpressionBlock> tmp = new ArrayList<ExpressionBlock> ();
		tmp.add(head);
		lists.add(tmp);
	}

	public boolean addLeaf(ExpressionBlock leaf) {
		boolean flag = false;
		if(head.getModuleName() == null) {
			this.head = leaf;
			lists.get(0).set(0, leaf);
			flag = true;
			return flag;
		}
		for(ArrayList<ExpressionBlock> l : lists) {
			for(ExpressionBlock el : l) {
				if(el.getValue().equals(leaf.getValueParent()) && el.getModuleName().equals(leaf.getModuleParentName())) {
					if(!nodes.contains(leaf) && l.indexOf(el)==l.size()-1) {
						nodes.add(leaf);
						l.add(leaf);
						this.lastAdded = leaf;
						flag = true;
					}
					else if(!nodes.contains(leaf) && l.indexOf(el)!=l.size()-1) {
						nodes.add(leaf);
						ArrayList<ExpressionBlock> tmp = new ArrayList<ExpressionBlock>();
						for(int i=0; i<=l.indexOf(el); i++) {
							tmp.add(l.get(i));
						}
						tmp.add(leaf);
						lists.add(tmp);
						this.lastAdded = leaf;

						flag = true;
					}
				}
				if(flag) {break;}
			}
			if(flag) {break;}
		}
		return flag;
	}

	public boolean addLeafBag(ExpressionBlock leaf) {
		boolean flag = false;
		if(head.getModuleName() == null) {
			this.head = leaf;
			lists.get(0).set(0, leaf);
			flag = true;
			return flag;
		}
		if(!nodes.contains(leaf) ) {
			nodes.add(leaf);
			lists.get(0).add(leaf);
			this.lastAdded = leaf;
			flag = true;
		}

		return flag;
	}

	public ArrayList<ExpressionBlock> getNodes(){
		return nodes;
	}

	public int size() {
		return lists.size();
	}

	public ArrayList<ExpressionBlock> get(int i){
		return lists.get(i);
	}

	public ExpressionBlock getLastAdded() {
		return this.lastAdded;
	}

	public ExpressionBlock getHead() {
		return head;
	}

	public ArrayList<ArrayList<ExpressionBlock>> getLists(){
		return lists;
	}

	public String prettyPrint() {
		int maxLen = 0;
		ArrayList<ExpressionBlock> toPrint = null;
		for(int i=0; i<lists.size(); i++) {
			if(lists.get(i).size()>maxLen) {
				toPrint = lists.get(i);
				maxLen = lists.get(i).size();
			}
		}
		return toPrint.toString();
	}

	public String toString() {
		return getNodes().toString();
	}
	
	public static void main(String args[])
	{
		ExpressionString n1 = new ExpressionString("adele");
		ExpressionString n2 = new ExpressionString("ale");
		ExpressionLiteral v0 = new ExpressionLiteral(TypeInt.getInstance(), 0);
		ExpressionLiteral v1 = new ExpressionLiteral(TypeInt.getInstance(), 1);
		ExpressionLiteral v2 = new ExpressionLiteral(TypeInt.getInstance(), 2);
		ExpressionLiteral v3 = new ExpressionLiteral(TypeInt.getInstance(), 3);
		ExpressionLiteral v4 = new ExpressionLiteral(TypeInt.getInstance(), 4);

		ExpressionBlock nb = new ExpressionBlock(n1,v0,n1,v0);
		ExpressionBlock toAdd1 = new ExpressionBlock(n1,v1,n1,v0);
		ExpressionBlock toAdd2 = new ExpressionBlock(n2,v1,n1,v0);
		ExpressionBlock toAdd3 = new ExpressionBlock(n1,v2,n1,v1);
		ExpressionBlock toAdd4 = new ExpressionBlock(n1,v2,n2,v1);
		ExpressionBlock toAdd5 = new ExpressionBlock(n2,v2,n2,v1);
		ExpressionBlock toAdd6 = new ExpressionBlock(n1,v3,n1,v2);

		TreeList<ExpressionBlock> albero = new TreeList<ExpressionBlock>(nb);
		albero.addLeafBag(toAdd1);
		albero.addLeafBag(toAdd3);
		albero.addLeafBag(toAdd2);
		albero.addLeafBag(toAdd4);
		albero.addLeafBag(toAdd5);
		albero.addLeafBag(toAdd6);

		// albero.addLeaf(nb,8);
		//albero.addLeaf(nb,12);
		//albero.addLeaf(nb,15);
		//albero.addLeaf(nb,17);

		//albero = albero.addLeaf(7);
		//System.out.println(albero.getHead().toString());

		System.out.println(albero.prettyPrint());
		System.out.println(albero.getNodes().toString());

		System.out.println("===================");
		TreeList<ExpressionBlock> albero2 = new TreeList<ExpressionBlock>();
		albero2.addHead(nb);
		albero2.addLeaf(nb);
		albero2.addLeaf(toAdd1);
		albero2.addLeaf(toAdd3);
		albero2.addLeaf(toAdd2);
		albero2.addLeaf(toAdd4);
		albero2.addLeaf(toAdd5);
		albero2.addLeaf(toAdd6);
		System.out.println(albero2.prettyPrint());
		System.out.println(albero2.getNodes().toString());

	}
}