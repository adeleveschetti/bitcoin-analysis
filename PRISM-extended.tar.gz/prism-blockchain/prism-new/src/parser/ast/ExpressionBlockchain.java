package parser.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import param.BigRational;
import parser.EvaluateContext;
import parser.visitor.ASTVisitor;
import prism.PrismLangException;

public class ExpressionBlockchain extends Expression{

	private String name;
	private int length;
	private TreeList<ExpressionBlock> blocks;

	public ExpressionBlockchain(){
		name = null;
		blocks = null;
		length = 0;
	}

	ExpressionBlockchain(String n){
		name = n;
		blocks = null;
		length = 0;
	}

	public ExpressionBlockchain(String n, TreeList<ExpressionBlock> b){
		name = n;
		this.blocks = new TreeList<ExpressionBlock>();
		if(b!=null && b.size()>0) {
			blocks.addHead(b.getHead());
			for(int i=0; i<b.size(); i++) {
				for(int j=0; j<b.get(i).size(); j++) {
					blocks.addLeaf(b.get(i).get(j));
				}
			}
		}
		length = blocks.size();
	}

	public ExpressionBlockchain(ExpressionBlock b){
		name = null;
		blocks = new TreeList<ExpressionBlock>();
		blocks.addHead(b);
		length = blocks.size();

	}

	public void setName(String n) {
		this.name = n;
	}

	/*
	 * public void setBlocks(List<ExpressionBlock> b) { for(int i=0; i<b.size();
	 * i++) { this.blocks.add(b.get(i)); } }
	 */

	public ExpressionBlockchain addBlock(Expression operand2) {
		if(this.blocks==null) {
			this.blocks = new TreeList<ExpressionBlock>();
			this.blocks.addHead((ExpressionBlock) operand2);
			length = blocks.size();
		}
		else {
			this.blocks.addLeaf((ExpressionBlock) operand2);
		}

		return this;
	}

	public String getName() {
		return this.name;
	}

	public int getLength() {
		return length;
	}

	public TreeList<ExpressionBlock> getBlocks() {
		return this.blocks;
	}

	@Override
	public boolean isConstant() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isProposition() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object evaluate(EvaluateContext ec) throws PrismLangException {
		if(this.blocks!=null && this.blocks.size()>0) {
			ExpressionBlockchain evaluated = new ExpressionBlockchain();
			evaluated.blocks = new TreeList<ExpressionBlock>(this.blocks.getHead().evaluateBlock(ec));
			for(int i=0; i<this.blocks.size(); i++) {
				for(int j=0; j<this.blocks.get(i).size(); j++) {
					evaluated.blocks.addLeaf((ExpressionBlock) this.blocks.get(i).get(j).evaluate(ec));
				}
			}
			return evaluated;
		}
		else {
			return new ExpressionBlockchain();
		}
	}

	@Override
	public BigRational evaluateExact(EvaluateContext ec) throws PrismLangException {
		if(this.blocks!=null && this.blocks.size()>0) {
			BigRational evaluated = new BigRational();
			for(int i=0; i<this.blocks.size(); i++) {
				for(int j=0; j<this.blocks.get(i).size(); j++) {
					evaluated.add(this.blocks.get(i).get(j).evaluateExact(ec));
				}
			}
			return evaluated;
		}
		else {
			throw new PrismLangException("Could not evaluate empty blockchains", this);
		}
	}

	@Override
	public boolean returnsSingleValue() {
		// TODO Auto-generated method 
		return false;
	}

	@Override
	public Expression deepCopy() {
		TreeList<ExpressionBlock> lb = new TreeList<ExpressionBlock>();
		if(blocks==null) {
			return null;
		}
		lb.addHead((ExpressionBlock) this.blocks.getHead().deepCopy());
		for(int i=0; i<this.blocks.size(); i++) {
			for(int j=0; j<this.blocks.get(i).size(); j++) {
				lb.addLeaf((ExpressionBlock) this.blocks.get(i).get(j).deepCopy());
			}
		}
		return new ExpressionBlockchain(this.name,lb);
	}

	public int compareTo(ExpressionBlockchain expr) {
		if(expr.getBlocks().size()!=this.blocks.size()) {
			return 0;
		}
		for(int i=0; i<this.blocks.size(); i++) {
			if(!this.blocks.get(i).equals(expr.getBlocks().get(i))) {
				return 0;
			}
		}
		return 1;
	}
	public ArrayList<ExpressionBlock> getMainChain(){
		int maxLen = 0;
		ArrayList<ExpressionBlock> mainChain = new ArrayList<ExpressionBlock>();
		for(int i=0; i<this.blocks.size(); i++) {
			if(this.blocks.get(i).size()>maxLen) {
				mainChain = this.blocks.get(i);
				maxLen = this.blocks.get(i).size();
			}

			else if(this.blocks.get(i).size()==maxLen) {
				if(this.blocks.get(i).contains(this.blocks.getLastAdded())) {
					mainChain = this.blocks.get(i);
					maxLen = this.blocks.get(i).size();
				}
			}

		}
		return mainChain;
	}

	@Override
	public Object accept(ASTVisitor v) throws PrismLangException {
		// TODO Auto-generated method stub
		return v.visit(this);

	}

	@Override
	public String toString() {
		return this.blocks.prettyPrint();
	}

	@SuppressWarnings("null")
	public int hashCode() {
		Object blockValues[] = null;
		for(int i=0; i<blocks.size(); i++) {
			blockValues[i] = blocks.get(i).hashCode();
		}
		return Arrays.hashCode(blockValues);
	}

}
