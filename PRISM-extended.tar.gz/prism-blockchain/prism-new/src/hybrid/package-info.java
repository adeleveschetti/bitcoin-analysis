/**
 * Access to the "Hybrid" engine: data structures and model checking algorithms that mix MTBDDs and explicit-state techniques.
 */
package hybrid;
