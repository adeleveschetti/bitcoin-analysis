/**
 * Implementation of approximate/statistical model checking techniques using the discrete event simulation engine.
 */
package simulator.method;
