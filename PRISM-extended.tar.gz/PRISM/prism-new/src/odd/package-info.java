/**
 * Access to ODDs (offset-labelled BDDs), used to facilitate indexing of states between BDDs and explicit-state data structures.
 */
package odd;
