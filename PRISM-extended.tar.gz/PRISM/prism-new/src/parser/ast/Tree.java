/*
 * Copyright 2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package parser.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;

import parser.type.TypeInt;
import prism.PrismTest;

/**
 * @author ycoppel@google.com (Yohann Coppel)
 * 
 * @param <T>
 *          Object's type in the tree.
 */
public class Tree<T> {

	private T head;

	private ArrayList<Tree<T>> leafs = new ArrayList<Tree<T>>();
	
	private ArrayList<T> nodes = new ArrayList<T>();
	
	private Tree<T> parent = null;

	private HashMap<T, Tree<T>> locate = new HashMap<T, Tree<T>>();

	public Tree(T head) {
		this.head = head;
		nodes.add(head);
		locate.put(head, this);
	}

	public void addLeaf(T root, T leaf) {
		boolean flag = false;
		if(leaf instanceof ExpressionBlock) {
			for (Entry<T, Tree<T>> key : locate.entrySet() ) {
				if(key.getKey() instanceof ExpressionBlock) {
					if(((ExpressionBlock) key.getKey()).getModuleName().equals(((ExpressionBlock) leaf).getModuleParentName()) && ((ExpressionBlock) key.getKey()).getValue().equals(((ExpressionBlock) leaf).getValueParent())) {
						if(!key.getValue().getNodes().contains(leaf)) {
							locate.get(key.getKey()).addLeaf(leaf);
							flag = true;
						}
					}
				}
				if(flag) {break;}

			}
		}
		else {
			if (locate.containsKey(root)) {
				locate.get(root).addLeaf(leaf);
			} else {
				addLeaf(root).addLeaf(leaf);
			}
		}
	}

	public ArrayList<T> getNodes(){
		return nodes;
	}
	
	public Tree<T> addLeaf(T leaf) {
		Tree<T> t = new Tree<T>(leaf);
		leafs.add(t);
		t.parent = this;
		t.locate = this.locate;
		locate.put(leaf, t);
		this.nodes.add(leaf);
		//t.nodes.add(leaf);
		return t;
	}

	public Tree<T> setAsParent(T parentRoot) {
		Tree<T> t = new Tree<T>(parentRoot);
		t.leafs.add(this);
		this.parent = t;
		t.locate = this.locate;
		t.locate.put(head, this);
		t.locate.put(parentRoot, t);
		return t;
	}

	public T getHead() {
		return head;
	}

	public Tree<T> getTree(T element) {
		return locate.get(element);
	}

	public Tree<T> getParent() {
		return parent;
	}

	public Collection<T> getSuccessors(T root) {
		Collection<T> successors = new ArrayList<T>();
		Tree<T> tree = getTree(root);
		if (null != tree) {
			for (Tree<T> leaf : tree.leafs) {
				successors.add(leaf.head);
			}
		}
		return successors;
	}

	public Collection<Tree<T>> getSubTrees() {
		return leafs;
	}

	public static <T> Collection<T> getSuccessors(T of, Collection<Tree<T>> in) {
		for (Tree<T> tree : in) {
			if (tree.locate.containsKey(of)) {
				return tree.getSuccessors(of);
			}
		}
		return new ArrayList<T>();
	}

	@Override
	public String toString() {
		return printTree(0);
	}

	private static final int indent = 2;

	public String printTree(int increment) {
		String s = "";
		String inc = "";
		for (int i = 0; i < increment; ++i) {
			inc = inc + " ";
		}
		s = inc + head;
		for (Tree<T> child : leafs) {
			s += "\n" + child.printTree(increment + indent);
		}
		return s;
	}

	
	public String prettyPrint() {
		String str = "";
		return str;
	}

	public static void main(String args[])
	{
		ExpressionString n1 = new ExpressionString("adele");
		ExpressionString n2 = new ExpressionString("ale");
		ExpressionLiteral v0 = new ExpressionLiteral(TypeInt.getInstance(), 0);
		ExpressionLiteral v1 = new ExpressionLiteral(TypeInt.getInstance(), 1);
		ExpressionLiteral v2 = new ExpressionLiteral(TypeInt.getInstance(), 2);
		ExpressionLiteral v3 = new ExpressionLiteral(TypeInt.getInstance(), 3);
		ExpressionLiteral v4 = new ExpressionLiteral(TypeInt.getInstance(), 4);

		ExpressionBlock nb = new ExpressionBlock(n1,v0,n1,v0);
		ExpressionBlock toAdd1 = new ExpressionBlock(n2,v1,n1,v0);
		ExpressionBlock toAdd2 = new ExpressionBlock(n1,v1,n1,v0);
		ExpressionBlock toAdd3 = new ExpressionBlock(n2,v2,n2,v1);
		ExpressionBlock toAdd4 = new ExpressionBlock(n1,v2,n2,v1);
		ExpressionBlock toAdd5 = new ExpressionBlock(n1,v3,n1,v1);
		ExpressionBlock toAdd6 = new ExpressionBlock(n1,v4,n1,v0);

		Tree<ExpressionBlock> albero = new Tree<ExpressionBlock>(nb);
		albero.addLeaf(nb,toAdd1);
		albero.addLeaf(nb,toAdd3);
		albero.addLeaf(nb,toAdd2);
		albero.addLeaf(nb,toAdd4);
		albero.addLeaf(nb,toAdd5);
		albero.addLeaf(nb,toAdd6);
		albero.addLeaf(nb,toAdd6);
		albero.addLeaf(nb,toAdd4);

		// albero.addLeaf(nb,8);
		//albero.addLeaf(nb,12);
		//albero.addLeaf(nb,15);
		//albero.addLeaf(nb,17);

		//albero = albero.addLeaf(7);
		//System.out.println(albero.getHead().toString());
		System.out.println(albero.toString());

	}
}