package parser.ast;

import java.util.ArrayList;

import parser.type.TypeInt;

public class Pair {
	private ExpressionBlock block;
	private ArrayList<Integer> votes  = new ArrayList<Integer>();

	public Pair(){
		block = null;
	}

	Pair(ExpressionBlock b, ArrayList<Integer> v){
		block = b;
		votes = v;
	}

	public void setBlock(ExpressionBlock newBlock) {
		block = newBlock;
	}

	public void setVote(int vote, int index) {
		if(index>=votes.size()) {
			for(int i=votes.size(); i<index; i++) {
				votes.add(i,0);
			}
			votes.add(index,vote);
		}
		else {
			votes.set(index,vote);
		}
	}

	public void setAllVotes(ArrayList<Integer> allVotes) {
		for(int i = 0; i<allVotes.size(); i++) {
			votes.add(i,allVotes.get(i));
		}
	}

	public double getVote(int index) {
		return votes.get(index);
	}

	public ExpressionBlock getBlock() {
		return block;
	}

	public ArrayList<Integer> getAllVotes(){
		return votes;
	}
	
	public int getTotVotes() {
		int totVotes = 0;
		if(votes!=null) {
			for(int i=0; i<votes.size(); i++) {
				totVotes = totVotes+votes.get(i);
			}
		}
		return totVotes;
	}

	public String toString() {
		String str = "(" + this.getBlock().toString() + "," +this.getAllVotes().toString()+")";
		return str;
	}

	public static void main(String args[])
	{
		ExpressionString n1 = new ExpressionString("adele");
		ExpressionString n2 = new ExpressionString("ale");
		ExpressionLiteral v0 = new ExpressionLiteral(TypeInt.getInstance(), 0);
		ExpressionLiteral v1 = new ExpressionLiteral(TypeInt.getInstance(), 1);
		ExpressionLiteral v2 = new ExpressionLiteral(TypeInt.getInstance(), 2);
		ExpressionLiteral v3 = new ExpressionLiteral(TypeInt.getInstance(), 3);
		ExpressionLiteral v4 = new ExpressionLiteral(TypeInt.getInstance(), 4);

		ExpressionBlock nb = new ExpressionBlock(n1,v0,n1,v0);
		ExpressionBlock toAdd1 = new ExpressionBlock(n1,v1,n1,v0);
		ExpressionBlock toAdd2 = new ExpressionBlock(n2,v1,n1,v0);
		ExpressionBlock toAdd3 = new ExpressionBlock(n1,v2,n1,v1);
		ExpressionBlock toAdd4 = new ExpressionBlock(n1,v2,n2,v1);
		ExpressionBlock toAdd5 = new ExpressionBlock(n2,v2,n2,v1);
		ExpressionBlock toAdd6 = new ExpressionBlock(n1,v3,n1,v2);
		;
		Pair newPair = new Pair();
		newPair.setBlock(nb);
		newPair.setVote(13,0);
		newPair.setVote(17,1);
		newPair.setVote(17,2);

		Pair newPair2 = new Pair();
		newPair2.setBlock(toAdd1);
		newPair2.setVote(3,0);
		newPair2.setVote(1,1);
		newPair2.setVote(8,5);
		newPair2.setVote(12,5);
		Pair newPair3 = new Pair();
		newPair3.setBlock(toAdd2);

		ArrayList<Pair> listOfVotedBlocks = new ArrayList<Pair>();
		listOfVotedBlocks.add(newPair);
		listOfVotedBlocks.add(newPair2);
		listOfVotedBlocks.add(newPair3);

		System.out.println(listOfVotedBlocks.toString());

	}

}