package parser.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import param.BigRational;
import parser.EvaluateContext;
import parser.visitor.ASTVisitor;
import prism.PrismLangException;

public class ExpressionBlockchain extends Expression{

	private String name;
	private int length;
	private TreeList<ExpressionBlock> blocks;
	private ExpressionBlock lastFinalized;
	private ExpressionBlock lastJustified;

	public ExpressionBlockchain(){
		name = null;
		blocks = null;
		length = 0;
		//mainChain = null;
		lastFinalized = null;
		lastJustified = null;

	}

	ExpressionBlockchain(String n){
		name = n;
		blocks = null;
		length = 0;
		//mainChain = null;
		lastFinalized = null;
		lastJustified = null;

	}

	public ExpressionBlockchain(String n, TreeList<ExpressionBlock> b){
		name = n;
		this.blocks = new TreeList<ExpressionBlock>();
		if(b!=null && b.size()>0) {
			blocks.addHead(b.getHead());
			for(int i=0; i<b.size(); i++) {
				for(int j=0; j<b.get(i).size(); j++) {
					blocks.addLeaf(b.get(i).get(j));
				}
			}
			lastFinalized = b.getHead();
			lastJustified = b.getHead();


		}
		else {
			lastFinalized = null;
			lastJustified = null;

		}
		//mainChain = getMainChain();
		length = blocks.size();
	}

	public ExpressionBlockchain(ExpressionBlock b){
		name = null;
		blocks = new TreeList<ExpressionBlock>();
		blocks.addHead(b);
		length = blocks.size();
		lastFinalized = b;
		lastJustified = b;


	}

	public void setName(String n) {
		this.name = n;
	}

	/*
	 * public void setBlocks(List<ExpressionBlock> b) { for(int i=0; i<b.size();
	 * i++) { this.blocks.add(b.get(i)); } }
	 */
	public ExpressionBlock getLastFinalized() {
		return this.lastFinalized;
	}

	public void setLastFinalized(ExpressionBlock b) {
		this.lastFinalized = b;
	}
	
	public ExpressionBlock getLastJustified() {
		return this.lastJustified;
	}

	public void setLastJustified(ExpressionBlock b) {
		this.lastJustified = b;
	}

	public ExpressionBlockchain addBlock(Expression operand2) {
		if(this.blocks==null) {
			this.blocks = new TreeList<ExpressionBlock>();
			this.blocks.addHead((ExpressionBlock) operand2);
			length = blocks.size();
		}
		else {
			this.blocks.addLeaf((ExpressionBlock) operand2);
		}
		return this;
	}

	public String getName() {
		return this.name;
	}

	public int getLength() {
		return length;
	}

	public TreeList<ExpressionBlock> getBlocks() {
		return this.blocks;
	}

	@Override
	public boolean isConstant() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isProposition() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object evaluate(EvaluateContext ec) throws PrismLangException {
		if(this.blocks!=null && this.blocks.size()>0) {
			ExpressionBlockchain evaluated = new ExpressionBlockchain();
			evaluated.blocks = new TreeList<ExpressionBlock>(this.blocks.getHead().evaluateBlock(ec));
			for(int i=0; i<this.blocks.size(); i++) {
				for(int j=0; j<this.blocks.get(i).size(); j++) {
					evaluated.blocks.addLeaf((ExpressionBlock) this.blocks.get(i).get(j).evaluate(ec));
				}
			}
			return evaluated;
		}
		else {
			return new ExpressionBlockchain();
		}
	}

	@Override
	public BigRational evaluateExact(EvaluateContext ec) throws PrismLangException {
		if(this.blocks!=null && this.blocks.size()>0) {
			BigRational evaluated = new BigRational();
			for(int i=0; i<this.blocks.size(); i++) {
				for(int j=0; j<this.blocks.get(i).size(); j++) {
					evaluated.add(this.blocks.get(i).get(j).evaluateExact(ec));
				}
			}
			return evaluated;
		}
		else {
			throw new PrismLangException("Could not evaluate empty blockchains", this);
		}
	}

	@Override
	public boolean returnsSingleValue() {
		// TODO Auto-generated method 
		return false;
	}

	@Override
	public Expression deepCopy() {
		TreeList<ExpressionBlock> lb = new TreeList<ExpressionBlock>();
		if(blocks==null) {
			return null;
		}
		lb.addHead((ExpressionBlock) this.blocks.getHead().deepCopy());
		for(int i=0; i<this.blocks.size(); i++) {
			for(int j=0; j<this.blocks.get(i).size(); j++) {
				lb.addLeaf((ExpressionBlock) this.blocks.get(i).get(j).deepCopy());
			}
		}
		return new ExpressionBlockchain(this.name,lb);
	}

	public int compareTo(ExpressionBlockchain expr) {
		if(expr.getBlocks().size()!=this.blocks.size()) {
			return 0;
		}
		for(int i=0; i<this.blocks.size(); i++) {
			if(!this.blocks.get(i).equals(expr.getBlocks().get(i))) {
				return 0;
			}
		}
		return 1;
	}
	public ArrayList<ExpressionBlock> getMainChain(){
		int maxLen = 0;
		ArrayList<ExpressionBlock> mainChain = new ArrayList<ExpressionBlock>();
		for(int i=0; i<this.blocks.size();i++) {
			for(int j=0; j<this.blocks.get(i).size() ; j++) {
				if(this.blocks.get(i).get(j).equals(lastFinalized) && this.blocks.get(i).size()>maxLen) {
					mainChain = this.blocks.get(i);
					maxLen = this.blocks.get(i).size();
				}
				else if(this.blocks.get(i).get(j).equals(lastFinalized) && (this.blocks.get(i).size()==maxLen && this.blocks.get(i).contains(this.blocks.getLastAdded())) && this.blocks.get(i).get(j).getMyBlock()) {
					//if()) {
						mainChain = this.blocks.get(i);
						maxLen = this.blocks.get(i).size();
					//}
				}
			}
		}
		return mainChain;
	}
	
	public ExpressionBlock findBlock(ExpressionBlock block) {
		ExpressionBlock toRet = null;
		boolean found = false;
		int maxLen = 0;

		for(int i=0; i<this.blocks.size()  ; i++) {
			for(int j=0; j<this.blocks.get(i).size() ; j++) {
				if(this.blocks.get(i).get(j).equals(block) && this.blocks.get(i).size()>maxLen) {
					toRet = this.blocks.get(i).get(this.blocks.get(i).size()-1);
					maxLen = this.blocks.get(i).size();
					found = true;
				}
				else if(this.blocks.get(i).get(j).equals(lastFinalized) && (this.blocks.get(i).size()==maxLen && this.blocks.get(i).contains(this.blocks.getLastAdded())) && this.blocks.get(i).get(j).getMyBlock()) {
					if(this.blocks.get(i).contains(this.blocks.getLastAdded())) {
						toRet = this.blocks.get(i).get(this.blocks.get(i).size()-1);
						maxLen = this.blocks.get(i).size();
						found = true;
					}
				}
			}
		}
	//	if(toRet == null) {toRet=this.head;}
		return toRet;
	}

	public ArrayList<ExpressionBlock> findChain(ExpressionBlock block) {
		ArrayList<ExpressionBlock> toRet = new ArrayList<ExpressionBlock>();
		boolean found = false;
		int maxLen = 0;

		for(int i=0; i<this.blocks.size() && !found; i++) {
			for(int j=0; j<this.blocks.get(i).size(); j++) {
				if(this.blocks.get(i).get(j).equals(block) && this.blocks.get(i).size()>maxLen) {
					toRet = this.blocks.get(i);
					maxLen = this.blocks.get(i).size();
					found = true;
				}
				else if(this.blocks.get(i).get(j).equals(block) && this.blocks.get(i).size()==maxLen) {
					if(this.blocks.get(i).contains(this.blocks.getLastAdded())) {
						toRet = this.blocks.get(i);
						maxLen = this.blocks.get(i).size();
						found = true;
					}
				}
			}
		}
	//	if(toRet == null) {toRet=this.head;}
		return toRet;
	}
	
	public ArrayList<ExpressionBlock> setMainChain(){
		int maxLen = 0;
		ArrayList<ExpressionBlock> mainChain = new ArrayList<ExpressionBlock>();
		for(int i=0; i<this.blocks.size(); i++) {
			if(this.blocks.get(i).size()>maxLen) {
				mainChain = this.blocks.get(i);
				maxLen = this.blocks.get(i).size();
			}

			else if(this.blocks.get(i).size()==maxLen) {
				if(this.blocks.get(i).contains(this.blocks.getLastAdded())) {
					mainChain = this.blocks.get(i);
					maxLen = this.blocks.get(i).size();
				}
			}

		}
		return mainChain;
	}

	@Override
	public Object accept(ASTVisitor v) throws PrismLangException {
		// TODO Auto-generated method stub
		return v.visit(this);

	}

	@Override
	public String toString() {
		ArrayList<ExpressionBlock> toPrint = null;
		toPrint = this.getMainChain();
		return toPrint.toString();
		//return this.blocks.prettyPrint();
	}

	@SuppressWarnings("null")
	public int hashCode() {
		Object blockValues[] = null;
		for(int i=0; i<blocks.size(); i++) {
			blockValues[i] = blocks.get(i).hashCode();
		}
		return Arrays.hashCode(blockValues);
	}

}
