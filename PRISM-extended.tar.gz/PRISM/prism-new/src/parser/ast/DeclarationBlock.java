package parser.ast;

import parser.type.TypeBlock;
import parser.visitor.ASTVisitor;
import prism.PrismLangException;

public class DeclarationBlock extends DeclarationType{

	private ExpressionBlock block;
	private String name;

	public DeclarationBlock() {
		this.name = null;
		this.block = null;
		setType(TypeBlock.getInstance());
	}

	public DeclarationBlock(String n, ExpressionBlock b) {
		this.name = n;
		this.block = b;
		setType(TypeBlock.getInstance());
	}

	public DeclarationBlock(ExpressionBlock b) {
		this.name = null;
		this.block = b;
		setType(TypeBlock.getInstance());
	}

	public void setBlock(ExpressionBlock b) {
		this.block = b;
	}

	public ExpressionBlock getBlock() {
		return this.block;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public ExpressionBlock getDefaultStart() {
		// TODO return Block(genesis,0) 
		if(block!=null) {
			return block;
		}
		else {
			return new ExpressionBlock();
		}
	}

	public Object accept(ASTVisitor v) throws PrismLangException
	{
		return v.visit(this);
	}

	@Override
	public String toString() {
		return "block {"+this.block.getModuleName()+","+this.block.getValue()+"}";
	}

	@Override
	public ASTElement deepCopy() {
		DeclarationBlock ret = new DeclarationBlock(name,(ExpressionBlock) block.deepCopy());
		return ret;		
	}



}
