package parser.ast;

import java.util.ArrayList;
import java.util.List;

import parser.type.TypeBlock;
import parser.type.TypeBlockchain;
import parser.visitor.ASTVisitor;
import prism.PrismLangException;

public class DeclarationBlockchain extends DeclarationType{

	private TreeList<ExpressionBlock> blocks = null;
	private String name;

	public DeclarationBlockchain() {
		this.name = null;
		this.blocks = null;
		setType(TypeBlockchain.getInstance());
	}

	public DeclarationBlockchain(String n, TreeList<ExpressionBlock> b) {
		this.name = n;
		this.blocks = b;
		setType(TypeBlockchain.getInstance());
	}

	public DeclarationBlockchain(TreeList<ExpressionBlock> b) {
		this.name = null;
		this.blocks = b;
		setType(TypeBlockchain.getInstance());
	}

	public DeclarationBlockchain(ExpressionBlock b) {
		this.name = null;
		this.blocks = new TreeList<ExpressionBlock>(b);
		//this.blocks.add(b);
		setType(TypeBlockchain.getInstance());
	}

	public DeclarationBlockchain(String n, ExpressionBlock b) {
		this.name = n;
		this.blocks = new TreeList<ExpressionBlock>(b);
		//this.blocks.add(b);
		setType(TypeBlockchain.getInstance());
	}

	public void setBlock(ExpressionBlock b, int i, int j) {
		this.blocks.get(i).set(j,b);
	}

	public ExpressionBlock getFirstBlock() {
		if(this.blocks!=null && this.blocks.size()>0) {
			return this.blocks.getHead();
		}
		else {
			return new ExpressionBlock();
		}
	}

	public ExpressionBlockchain getBlockchain() {
		return new ExpressionBlockchain(null,this.blocks);
	}

	public TreeList<ExpressionBlock> getBlocks() {
		return this.blocks;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public ExpressionBlockchain getDefaultStart() {
		// TODO return new Blockchain
		if(this.blocks!=null && this.blocks.size()>0) {
			return new ExpressionBlockchain(this.name,this.blocks);
		}
		else {
			return new ExpressionBlockchain();
		}
	}

	public Object accept(ASTVisitor v) throws PrismLangException
	{
		return v.visit(this);
	}

	@Override
	public String toString() {
		String ret = "blockchain [";
		if(this.blocks!=null && this.blocks.size()>0) {
			for(int i=0; i<this.blocks.size(); i++) {
				ret = ret + this.blocks.get(i).toString() ;
				if(i!=this.blocks.size()-1) {ret = ret + ",";}
				else {ret = ret + "]";}
			}
		}
		else {
			ret = ret + "]";
		}
		return ret;
	}

	@Override
	public ASTElement deepCopy() {
		TreeList<ExpressionBlock> tmp = new TreeList<ExpressionBlock>();
		
		if(blocks!=null && blocks.getHead()!=null) {
			tmp.addHead((ExpressionBlock) this.getBlocks().getHead().deepCopy());
			for(int i=0; i<blocks.size(); i++) {
				for(int j=1; j<blocks.get(i).size(); j++) {
					tmp.addLeaf((ExpressionBlock) blocks.get(i).get(j).deepCopy());
				}
			}
		}
		DeclarationBlockchain ret = new DeclarationBlockchain(name,tmp);
		return ret;		
	}


}
