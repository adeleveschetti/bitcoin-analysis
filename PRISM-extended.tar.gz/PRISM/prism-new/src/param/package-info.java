/**
 * Classes for parametric model checking.
 */
package param;
