/**
 * Text editor for PEPA models in the GUI.
 */
package userinterface.model.pepaModel;
