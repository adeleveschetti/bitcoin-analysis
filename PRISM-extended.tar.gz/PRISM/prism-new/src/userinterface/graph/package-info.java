/**
 * Graph plotting/editing functionality used in the GUI.
 */
package userinterface.graph;
