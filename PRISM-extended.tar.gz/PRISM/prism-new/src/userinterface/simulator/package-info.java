/**
 * The user interface to the simulator supplied in the GUI.
 */
package userinterface.simulator;
