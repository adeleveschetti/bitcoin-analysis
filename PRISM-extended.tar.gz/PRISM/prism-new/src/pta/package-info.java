/**
 * Probabilistic timed automata (PTA) model checking, including DBM library.
 */
package pta;
